package lithan.com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lithan.com.bean.myuser;
import lithan.com.dao.UserRepo;



@Service
@Transactional
public class userservice {
	
	@Autowired
	private UserRepo repo;
	
	public void save(myuser user) {
		user.setPasswords(user.getPasswords());
		repo.save(user);
		}
	
		public List<myuser> listAll(){
			return(List<myuser>) repo.findAll();
		}
		
		
	
	//Register Authentication
	public String RegisterUser (String username, String email, String passwords) {
		myuser user = new myuser();
		user.setUsername(username);
		user.setEmail(email);
		user.setPasswords(passwords);
		user.setAddress(null);
		user.setContactNo(null);
		user.setSession_time(null);
		user.setUserType("User");
		save(user);
		return "User registered successfully!";
		
	}
	
	//Login Authentication
	public myuser LoginUser (String username, String passwords) {
		Optional<myuser> optionalmyuser = repo.findByusername(username);
		if(optionalmyuser.isPresent()) {
			myuser user = optionalmyuser.get();
			if(passwords.equals(user.getPasswords())) {
				return user;
			}
		}
		return null;
	}

	public myuser get(Long id) {
		return repo.findById(id).orElseThrow(() -> new RuntimeException("User not found with id:" + id));
	}
	
	public Boolean VerifyPassword(Long currentUserID, String newPass) {
		Optional<myuser> optionalUser = Optional.ofNullable(get(currentUserID));
		if (optionalUser.isPresent()) {
			myuser user = optionalUser.get();
			if (user.getPasswords().equals(newPass)) {
				return true;
			}else {
				return false;
			}
		}return false;
	}

}
