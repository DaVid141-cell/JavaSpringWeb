package lithan.com.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lithan.com.bean.mybankuser;
import lithan.com.dao.userrepoD;

@Service
@Transactional
public class mybackservice {
	@Autowired
	userrepoD usrrep;
	public void saveuser(mybankuser us)
	{
		usrrep.save(us);
	}
	public List<mybankuser> viewclientde()
	{
		
		return (List<mybankuser>) usrrep.findAll();
	}

}
