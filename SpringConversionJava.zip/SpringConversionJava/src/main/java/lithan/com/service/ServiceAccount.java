package lithan.com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lithan.com.bean.Account;
import lithan.com.dao.AccRepo;

@Service
@Transactional
public class ServiceAccount {
	@Autowired
	AccRepo repo;
	
	public void save(Account account) {
		repo.save(account);
	}
	
	public List<Account> listAll(){
		List<Account> data = (List<Account>) repo.findAll();
		return data;
	}
	
	public void delete(Long id) {
		repo.deleteById(id);
	}
	
	public List<Account> getAccountsByUserID(Long userId){
		return repo.findByUser_UserID(userId);
	}
}
