package lithan.com.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lithan.com.bean.Transaction;
import lithan.com.dao.transactionsRepo;

@Service
@Transactional
public class ServiceTransaction {
	@Autowired
	transactionsRepo repo;
	
	public void save(Transaction transaction) {
		repo.save(transaction);
	}
	
	public List<Transaction> listAll(){
		List<Transaction> data = (List<Transaction>) repo.findAll();
		return data;
	}
	
	public Transaction get(Long id) {
		return repo.findById(id).get();
	}
	
	public void delete(Long id) {
		repo.deleteById(id);
	}
}
