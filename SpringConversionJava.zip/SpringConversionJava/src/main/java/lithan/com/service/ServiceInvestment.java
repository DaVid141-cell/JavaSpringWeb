package lithan.com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lithan.com.bean.InvestmentPortfolio;
import lithan.com.bean.investmentPlan;
import lithan.com.dao.investmentPlanRepo;

@Service
public class ServiceInvestment {
	@Autowired
	investmentPlanRepo repo;
	
	public void save(investmentPlan Plan) {
		repo.save(Plan);
	}
	
	public List<investmentPlan>	listAll(){
		return (List<investmentPlan>) repo.findAll();
	}
	
	public investmentPlan getByID(Long id) {
		return repo.findById(id).orElse(null);	
	}
	
	public void deletePortfolio(Long id) {
		repo.deleteById(id);
	}
	
	public InvestmentPortfolio calculationsRT (String investmentType, double initialAmount, double monthlyAmount) {
		investmentPlan plan = getinvestmentPlanByType(investmentType); // fetches the investment plan based on the investmentype of the user
		
		if (plan == null) {
			throw new IllegalArgumentException("Invalid investment type");
		}
		//using the stored details for calculations
		double maxReturn = plan.getMaxPredictReturn();
		double minReturn = plan.getMinPredictReturn();
		double taxRate = plan.getTaxRate();
		double fees = plan.getMonthlyFee();
		
		// this will convert the user input into double type for calculations
		double initialAmountEF = initialAmount;
		double monthlyAmountEF = monthlyAmount;
		
		//this is to calculate the predictions between 1, 5 and 10 years of investment 
		double[] years = {1, 5, 10};
		StringBuilder results = new StringBuilder();
		
		for (double year : years) {
			double totalInvested = initialAmountEF + monthlyAmountEF * 12 * year; // total investment amount
			
			double maxProfit = totalInvested * (maxReturn / 100) * year; // max and min amount
			double minProfit = totalInvested * (minReturn /100) * year;
			
			double totalTax = maxProfit * (taxRate / 100); // tax to be total
			
			double totalFees = (monthlyAmountEF * (fees/100)) * 12 * year; // fee to be total 
			
			//append results for each year this will integrate this into a HTML format with all of the calculations results
			results.append(String.format(
	                "<b>After %.0f year(s):</b><br>" +
	                "Max Return: &#163;%.2f<br>" +
	                "Min Return: &#163;%.2f<br>" +
	                "Total Tax: &#163;%.2f<br>" +
	                "Total Fees: &#163;%.2f<br><br>",
	                year, totalInvested + maxProfit - totalTax - totalFees,
	                totalInvested + minProfit - totalTax - totalFees,
	                Math.round(totalTax * 100.0) / 100.0, // Round to 2 decimal places
	                Math.round(totalFees * 100.0) / 100.0  // Round to 2 decimal places
	            ));
		}
		// creates and return to the investmentPortfolio object
		InvestmentPortfolio portfolio = new InvestmentPortfolio();
        portfolio.setInitialLumpSum(initialAmountEF);
        portfolio.setMonthlyInvestment(monthlyAmountEF);
        portfolio.setInvestmentPlan(plan);
        portfolio.setSummary(results.toString());
        
        return portfolio;
		
	}
	// feteching the investment plan based on the investment type
	private investmentPlan getinvestmentPlanByType(String investmentType) {
		//query for fecthing the investmentPlan based on the investment type choosen
		return repo.findByPlanName(investmentType);
	}


	
}	

