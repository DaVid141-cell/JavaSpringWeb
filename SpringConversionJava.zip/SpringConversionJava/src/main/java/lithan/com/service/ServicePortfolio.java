package lithan.com.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lithan.com.bean.InvestmentPortfolio;
import lithan.com.dao.portfolioRepo;

@Service
public class ServicePortfolio {
	@Autowired
	private portfolioRepo repo;
	
	public List<InvestmentPortfolio> getAllPortfolios(){
		return (List<InvestmentPortfolio>) repo.findAll();
	}
	
	public InvestmentPortfolio getPortfolioById(Long id) {
		return repo.findById(id).orElse(null);
	}
	
	public void deletePortfolio (Long id) {
		repo.deleteById(id);
	}

}
