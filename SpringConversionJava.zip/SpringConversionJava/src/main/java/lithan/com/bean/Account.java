package lithan.com.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name ="account")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column (name ="AccountID")
	private Long AccountID;
	
	@ManyToOne
	@JoinColumn(name = "UserID", nullable = false)
	private myuser user;
	
	@Column (name ="Accountname")
	private String Accountname;
	
	@Column (name ="AccountType")
	private String AccountType;
	
	@Column (name ="balance", nullable = false, precision = 10, scale = 2)
	private double Balance;

	public Long getAccountID() {
		return AccountID;
	}

	public void setAccountID(Long accountID) {
		AccountID = accountID;
	}

	public myuser getUser() {
		return user;
	}

	public void setUser(myuser user) {
		this.user = user;
	}

	public String getAccountname() {
		return Accountname;
	}

	public void setAccountname(String accountname) {
		Accountname = accountname;
	}

	public String getAccountType() {
		return AccountType;
	}

	public void setAccountType(String accountType) {
		AccountType = accountType;
	}

	public double getBalance() {
		return Balance;
	}

	public void setBalance(double balance) {
		Balance = balance;
	}
	
	
	//getter and setter
	
	
	
	
	
}
