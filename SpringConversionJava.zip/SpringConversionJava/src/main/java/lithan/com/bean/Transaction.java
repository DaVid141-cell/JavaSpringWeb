package lithan.com.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table (name = "transaction")
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TransactionID", nullable = false)
	private Integer transactionID;
	
	@ManyToOne
	@JoinColumn(name = "UserID", referencedColumnName = "user_id", nullable = false)
	private myuser user;
	
	@ManyToOne
	@JoinColumn(name = "SourceCurrencyID", referencedColumnName = "CurrencyID", nullable = false)
	private currency sourceCurrency;
	
	@ManyToOne
    @JoinColumn(name = "TargetCurrencyID", referencedColumnName = "CurrencyID", nullable = false)
    private currency targetCurrency;
	
	@Column(name = "Amount", precision = 10, scale = 2, nullable = false)
    private Double amount; // DECIMAL(10,2), not null, with constraints

    @Column(name = "ConvertedAmount", precision = 10, scale = 2, nullable = false)
    private Double convertedAmount; // DECIMAL(10,2), not null

    @Column(name = "Fee", precision = 10, scale = 2, nullable = false)
    private Double fee; // DECIMAL(10,2), not null

    @Column(name = "TransactionDate", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date transactionDate;

	public Integer getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(Integer transactionID) {
		this.transactionID = transactionID;
	}

	public myuser getUser() {
		return user;
	}

	public void setUser(myuser user) {
		this.user = user;
	}

	public currency getSourceCurrency() {
		return sourceCurrency;
	}

	public void setSourceCurrency(currency sourceCurrency) {
		this.sourceCurrency = sourceCurrency;
	}

	public currency getTargetCurrency() {
		return targetCurrency;
	}

	public void setTargetCurrency(currency targetCurrency) {
		this.targetCurrency = targetCurrency;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Double getConvertedAmount() {
		return convertedAmount;
	}

	public void setConvertedAmount(Double convertedAmount) {
		this.convertedAmount = convertedAmount;
	}

	public Double getFee() {
		return fee;
	}

	public void setFee(Double fee) {
		this.fee = fee;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
    
    
}
