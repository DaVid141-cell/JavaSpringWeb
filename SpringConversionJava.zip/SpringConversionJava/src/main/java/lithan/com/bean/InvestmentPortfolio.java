package lithan.com.bean;


import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "investmentportfolio")
public class InvestmentPortfolio {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PortfolioID", nullable = false)
	private Integer portfolioID;
	
	@ManyToOne
	@JoinColumn(name = "PlanID", referencedColumnName = "PlanID")
	private investmentPlan investmentPlan;
	
	@ManyToOne
	@JoinColumn(name = "UserID", referencedColumnName = "user_id", nullable = false)
	private myuser user;
	
	@Column(name = "InitialLumpSum", precision = 15, scale = 2, nullable = false)
	private Double initialLumpSum;
	
	@Column(name = "MonthlyInvestment", precision = 15, scale = 2, nullable = false)
	private Double monthlyInvestment;
	
	@Column(name = "StartDate", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date startDate;
	
	@Column(name = "EndDate", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date endDate;
	
	@Column(name = "MaxReturn", precision = 15, scale = 2, nullable = false)
	private Double maxReturn;

	@Column(name = "MinReturn", precision = 15, scale = 2, nullable = false)
	private Double minReturn;

	@Column(name = "Fees", precision = 15, scale = 2, nullable = false)
	private Double fees;

	@Column(name = "Taxes", precision = 15, scale = 2, nullable = false)
	private Double taxes;

	@Column(name = "NetAmount", precision = 15, scale = 2, nullable = false)
	private Double netAmount;

	@Column(name = "Summary", columnDefinition = "TEXT")
	private String summary;

	
	//setter and getter
	
	public Integer getPortfolioID() {
		return portfolioID;
	}

	public void setPortfolioID(Integer portfolioID) {
		this.portfolioID = portfolioID;
	}

	public investmentPlan getInvestmentPlan() {
		return investmentPlan;
	}

	public void setInvestmentPlan(investmentPlan investmentPlan) {
		this.investmentPlan = investmentPlan;
	}

	public myuser getUser() {
		return user;
	}

	public void setUser(myuser user) {
		this.user = user;
	}

	public Double getInitialLumpSum() {
		return initialLumpSum;
	}

	public void setInitialLumpSum(Double initialLumpSum) {
		this.initialLumpSum = initialLumpSum;
	}

	public Double getMonthlyInvestment() {
		return monthlyInvestment;
	}

	public void setMonthlyInvestment(Double monthlyInvestment) {
		this.monthlyInvestment = monthlyInvestment;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Double getMaxReturn() {
		return maxReturn;
	}

	public void setMaxReturn(Double maxReturn) {
		this.maxReturn = maxReturn;
	}

	public Double getMinReturn() {
		return minReturn;
	}

	public void setMinReturn(Double minReturn) {
		this.minReturn = minReturn;
	}

	public Double getFees() {
		return fees;
	}

	public void setFees(Double fees) {
		this.fees = fees;
	}

	public Double getTaxes() {
		return taxes;
	}

	public void setTaxes(Double taxes) {
		this.taxes = taxes;
	}

	public Double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(Double netAmount) {
		this.netAmount = netAmount;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}
	
	

	@Override
	public int hashCode() {
		return Objects.hash(portfolioID);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		InvestmentPortfolio that = (InvestmentPortfolio) obj;
		return Objects.equals(portfolioID, that.portfolioID);
	}

	@Override
	public String toString() {
		return "InvestmentPortfolio [portfolioID=" + portfolioID + ", investmentPlan=" + investmentPlan + ", user="
				+ user + ", initialLumpSum=" + initialLumpSum + ", monthlyInvestment=" + monthlyInvestment
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", maxReturn=" + maxReturn + ", minReturn="
				+ minReturn + ", fees=" + fees + ", taxes=" + taxes + ", netAmount=" + netAmount + ", summary="
				+ summary + "]";
	} 
	
}
