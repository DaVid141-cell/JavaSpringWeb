package lithan.com.bean;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Column;

@Entity
@Table (name = "currency")
public class currency {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CurrencyID")
	private Long CurrencyID;
	
	@Column(name = "CurrencyCode", nullable = false, length = 3)
	private String code;
	
	@Column(name = "CurrencyName", nullable = false)
	private String CurrencyName;
	
	@Column(name = "ExchangeRate", nullable = false, precision = 10, scale = 2)
	private Double ExchangeRate;
	
	//Setter and getter
	public Long getCurrencyID() {
		return CurrencyID;
	}

	public void setCurrencyID(Long currencyID) {
		CurrencyID = currencyID;
	}

	public String getCurrencyCode() {
		return code;
	}

	public void setCurrencyCode(String CurrencyCode) {
		code = CurrencyCode;
	}

	public String getCurrencyName() {
		return CurrencyName;
	}

	public void setCurrencyName(String currencyName) {
		CurrencyName = currencyName;
	}

	public Double getExchangeRate() {
		return ExchangeRate;
	}

	public void setExchangeRate(Double exchangeRate) {
		ExchangeRate = exchangeRate;
	}
	
}
