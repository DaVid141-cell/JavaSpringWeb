package lithan.com.bean;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Column;

@Entity
@Table(name = "investmentplan")
public class investmentPlan {	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PlanID", nullable = false)
	private Integer planID;
	
	@Column(name = "PlanName", nullable = false)
	private String planName;
	
	@Column(name = "MaxInvestmentYears", nullable = false)
	private Integer maxInvestmentYears;
	
	@Column(name = "MinMonthlyInvestment", precision = 10, scale = 2, nullable = false)
	private Double minMonthlyInvestment;
	
	@Column(name = "MinInitialLumpSum", precision = 10, scale = 3, nullable = false)
	private Double minInitialLumpSum;
	
    @Column(name = "MinPredictReturn", precision = 10, scale = 4, nullable = false)
	private Double minPredictReturn;
	
    @Column(name = "MaxPredictReturn", precision = 10, scale = 5, nullable = false)
    private Double maxPredictReturn;
	
    @Column(name = "TaxRate", precision = 10, scale = 6, nullable = false)
    private Double taxRate;
	
    @Column(name = "MonthlyFee", precision = 10, scale = 7, nullable = false)
    private Double monthlyFee;
	
	
	
	public Integer getPlanID() {
		return planID;
	}
	public void setPlanID(Integer planID) {
		this.planID = planID;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public Integer getMaxInvestmentYears() {
		return maxInvestmentYears;
	}
	public void setMaxInvestmentYears(Integer maxInvestmentYears) {
		this.maxInvestmentYears = maxInvestmentYears;
	}
	public Double getMinMonthlyInvestment() {
		return minMonthlyInvestment;
	}
	public void setMinMonthlyInvestment(Double minMonthlyInvestment) {
		this.minMonthlyInvestment = minMonthlyInvestment;
	}
	public Double getMinInitialLumpSum() {
		return minInitialLumpSum;
	}
	public void setMinInitialLumpSum(Double minInitialLumpSum) {
		this.minInitialLumpSum = minInitialLumpSum;
	}
	public Double getMinPredictReturn() {
		return minPredictReturn;
	}
	public void setMinPredictReturn(Double minPredictReturn) {
		this.minPredictReturn = minPredictReturn;
	}
	public Double getMaxPredictReturn() {
		return maxPredictReturn;
	}
	public void setMaxPredictReturn(Double maxPredictReturn) {
		this.maxPredictReturn = maxPredictReturn;
	}
	public Double getTaxRate() {
		return taxRate;
	}
	public void setTaxRate(Double taxRate) {
		this.taxRate = taxRate;
	}
	public Double getMonthlyFee() {
		return monthlyFee;
	}
	public void setMonthlyFee(Double monthlyFee) {
		this.monthlyFee = monthlyFee;
	}
	

}
