package lithan.com.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import lithan.com.bean.mybankuser;
import lithan.com.service.mybackservice;

@Controller
public class LoginContriller {
	@Autowired
	mybackservice objser;
	@RequestMapping("/register")
	public String register(Map<String, Object> model)
	{
		mybankuser us = new mybankuser();
		model.put("savebankuser",us);
		
		return "Register";
	}
	
	@RequestMapping(value = "/saveuser", method = RequestMethod.POST )
	public void saveuserinfo(@ModelAttribute("savebankuser") mybankuser us)
	{
		//System.out.println(us);
		objser.saveuser(us);
		//return "Register";
	}
	

}
