package lithan.com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import lithan.com.bean.Account;
import lithan.com.bean.Transaction;
import lithan.com.bean.currency;
import lithan.com.bean.myuser;
import lithan.com.service.ServiceAccount;
import lithan.com.service.ServiceCurrency;
import lithan.com.service.ServiceTransaction;
import lithan.com.service.userservice;

@Controller
public class dashboardControl {
	
	@Autowired
	private ServiceTransaction serviceTransaction;
	
	@Autowired
	private ServiceCurrency currencyService;
	
	@Autowired
	private ServiceAccount AccountService;
	@Autowired
	private userservice UserService;
	
	@RequestMapping("/")
	public ModelAndView home() {
	    ModelAndView mav = new ModelAndView("home");
	    return mav;
	}
	
	@RequestMapping("/User/Currency-exchange")
	public ModelAndView conversionExchange(HttpSession session) {
		myuser sessionmyuser = (myuser) session.getAttribute("currentmyuser");
		if (sessionmyuser == null) {
			ModelAndView mav = new ModelAndView("form");
			return mav;
		}
		ModelAndView mav = new ModelAndView("User/Currency");
		List<currency> currencies = currencyService.listAll();
		List<Transaction> listTrans = serviceTransaction.listAll();
		mav.addObject("currencies",	currencies);
		mav.addObject("transactions", listTrans);
		return mav;
	}
	
	@RequestMapping("/User/Dashboard")
	public ModelAndView home(HttpSession session) {
		myuser sessionmyuser = (myuser) session.getAttribute("currentmyuser");
		if (sessionmyuser == null) {
			ModelAndView mav = new ModelAndView("form");
			return mav;
		}
		
		List<Transaction> NumTrans = serviceTransaction.listAll();
		ModelAndView mav = new ModelAndView("User/Dashboard");
		
		List<Account> Accounts = AccountService.getAccountsByUserID(sessionmyuser.getUserID());
		myuser currentmyuser = UserService.get(sessionmyuser.getUserID());
		Account selectedAccount = (Account) session.getAttribute("selectedAccount");
		if (selectedAccount == null && !Accounts.isEmpty()) {
			session.setAttribute("selectedAccount", Accounts.get(0));
			selectedAccount = Accounts.get(0);
		}
		
		mav.addObject("User", currentmyuser);
		mav.addObject("Account", Accounts);
		mav.addObject("selectedAccount", selectedAccount);
		
		String toastMessage = (String) session.getAttribute("toastMessage");
		if (toastMessage != null) {
			mav.addObject("toastMessage", toastMessage);
			session.removeAttribute("toastMessage");
		}
		mav.addObject("listTrans", NumTrans);
		return mav;
	}

}
