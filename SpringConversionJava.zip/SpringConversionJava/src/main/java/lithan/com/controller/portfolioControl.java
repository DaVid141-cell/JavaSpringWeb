package lithan.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import lithan.com.service.ServiceInvestment;
import lithan.com.service.ServicePortfolio;

@Controller
public class portfolioControl {
	
	@Autowired
	private ServicePortfolio portfolioService;
	@Autowired
	private ServiceInvestment investmentService;
}
