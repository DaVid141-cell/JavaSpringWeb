package lithan.com.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import lithan.com.bean.myuser;
import lithan.com.service.userservice;

@Controller
public class NavController {
	
	@Autowired
	private userservice UserService;

	@RequestMapping("/home")
	public ModelAndView homepage() {
		ModelAndView mav = new ModelAndView("home");
		return mav;
	}

	@RequestMapping("/Login/Register/form")
	public ModelAndView showRegisterForm() {
		ModelAndView mav = new ModelAndView("form");
		return mav;
	}
	

	
	@PostMapping("/register")
	public String registerUser(@RequestParam("username") String username, @RequestParam("email") String email,
			@RequestParam("passwords") String passwords, HttpSession session) {
		String message = UserService.RegisterUser(username, email, passwords);
		session.setAttribute("toastMessage", message);
		return "redirect:/Login/Register/form";
	}
	
	@PostMapping("/form")
	public String loginUser(@RequestParam("username") String username, @RequestParam("passwords") String passwords, HttpSession session) {
		myuser user = UserService.LoginUser(username, passwords);
		if(user != null) {
			session.setAttribute("currentmyuser", user);
			String message = "Login successful!";
			session.setAttribute("toastMessage", message);
			return "redirect:/User/Dashboard";
		}
		else {
			String message = "Invalid email or password!";
			session.setAttribute("toastMessage", message);
			return "redirect:/index";
		}
	}
	
	@RequestMapping("/logout")
	public String logoutUser(HttpSession session) {
		// Invalidate the current session
		session.invalidate();
		return "redirect:/home";
	}
	
	
	/*@RequestMapping("/viewclient")
	public ModelAndView viewclient()
	{
		
		List<mybankuser>  us=mybk.viewclientde();
			
		ModelAndView mav = new ModelAndView();
		mav.addObject("viewcl", us);

			System.out.println(us);
			mav.setViewName("viewClientdetails");
			return  mav; 
				
		
		}*/

}
