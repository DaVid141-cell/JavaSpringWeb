package lithan.com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import lithan.com.bean.Account;
import lithan.com.bean.Transaction;
import lithan.com.bean.currency;
import lithan.com.bean.myuser;
import lithan.com.service.ServiceAccount;
import lithan.com.service.ServiceCurrency;
import lithan.com.service.ServiceTransaction;
import lithan.com.service.userservice;

@Controller
public class currencyControl {
	
	@Autowired
	private ServiceCurrency currencyService;
	
	@Autowired
	private userservice UserService;
	
	@Autowired
	private ServiceTransaction TransactionsService;
	
	@Autowired
	private ServiceAccount AccountService;
	
	@GetMapping("/currencies")
	public ResponseEntity<List<currency>> getAllCurrencies(){
		List<currency> currencies = currencyService.listAll();
		return ResponseEntity.ok(currencies);
	}
		
	
}
