package lithan.com.controller;


import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lithan.com.bean.Transaction;
import lithan.com.bean.currency;
import lithan.com.bean.myuser;
import lithan.com.service.ServiceCurrency;
import lithan.com.service.ServiceTransaction;

public class transactionControl {
	
	@Autowired
	private ServiceTransaction transactionService;
	
	@Autowired
	private ServiceCurrency currencyService;
	
	@PostMapping("/transaction/saved")
	public String Savetransaction(@RequestParam("SourceCurrencyID") Long sourceCurrencyID, @RequestParam("TargetCurrencyID") Long targetCurrencyID,
			@RequestParam("Amount") String amountCS, @RequestParam("ConvertedAmount") String convertedAmountCS, @RequestParam("Fee") String feeCS,
			HttpSession session) {
		
		myuser sessionmyuser = (myuser) session.getAttribute("currentmyuser");
		if (sessionmyuser == null) {
			return "redirect:/Login/Register/form";
		}
		
		Double amount = 0.0;
		Double convertedAmount = 0.0;
		Double fee = 0.0;
		try {
			amount = Double.parseDouble(amountCS);
			convertedAmount = Double.parseDouble(convertedAmountCS);
			fee = Double.parseDouble(feeCS);
		} catch (NumberFormatException e) {
			session.setAttribute("toastMessage", "Can't make transaction, try again later.");
			System.out.println(e);
		}
		
		currency sourceCurrency = currencyService.get(sourceCurrencyID);
		currency targetCurrency = currencyService.get(targetCurrencyID);
		
		if (sourceCurrency == null || targetCurrency == null) {
			session.setAttribute("toastMessage", "Can't make transaction, try again later.");
		}
		
		Transaction transaction = new Transaction();
		transaction.setUser(sessionmyuser);
		transaction.setSourceCurrency(sourceCurrency);
		transaction.setTargetCurrency(targetCurrency);
		transaction.setAmount(amount);
		transaction.setConvertedAmount(convertedAmount);
		transaction.setFee(fee);
		transaction.setTransactionDate(new Date());
		
		try {
			transactionService.save(transaction);
			session.setAttribute("toastMessage", "Successfully created Transaction.");
			return "redirect:/User/Dashboard";
		} catch (Exception e) {
			System.out.println("GoodBye!");
			e.printStackTrace();
		}
		return "redirect:/User/Currency-exchange";

	}
}
