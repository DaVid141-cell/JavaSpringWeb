package lithan.com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import lithan.com.bean.Account;
import lithan.com.bean.myuser;
import lithan.com.service.ServiceAccount;
import lithan.com.service.userservice;

@Controller
public class profileControl {
	
	@Autowired
	private ServiceAccount AccountService;
	
	@Autowired
	private userservice UserService;
	
	
	@RequestMapping("/User/profile-view")
	public ModelAndView profileView (HttpSession session) {
		myuser sessionmyuser = (myuser) session.getAttribute("currentmyuser");
		if (sessionmyuser != null) {
			myuser currentmyuser = UserService.get(sessionmyuser.getUserID());
			List<Account> accounts = AccountService.getAccountsByUserID(sessionmyuser.getUserID());
			
			
			Account selectedAccount = (Account) session.getAttribute("selectedAccount");
			if (selectedAccount == null && !accounts.isEmpty()){
				session.setAttribute("selectedAccount", accounts.get(0));
				selectedAccount = accounts.get(0);
			}
			
			ModelAndView mav = new ModelAndView("User/profile");
			mav.addObject("myuser", currentmyuser);
			mav.addObject("Accounts", accounts);
			mav.addObject("selectedAccount", selectedAccount);
			return mav;
			
		} else {
			return new ModelAndView("/Login/Register/form");
		}
	}
	
	
	@RequestMapping("/User/info/save")
	public String saveProfile(@RequestParam("username") String username, @RequestParam("email") String email,
			@RequestParam("contactNo") String contactNo, @RequestParam("address") String address, @RequestParam(value = "userType", required = false) String userType,
			@RequestParam(value = "currentPass", required = false) String currentPass,
			@RequestParam(value = "newPass", required = false) String newPass, HttpSession session) {
		
		myuser sessionmyuser = (myuser) session.getAttribute("currentmyuser");
		if (sessionmyuser == null) {
			return "redirect:/Login/Register/form";
		}
		
		myuser currentmyuser = UserService.get(sessionmyuser.getUserID());
		
		currentmyuser.setUsername(username);
		currentmyuser.setEmail(email);
		currentmyuser.setContactNo(contactNo);
		currentmyuser.setAddress(address);
		currentmyuser.setUserType(userType);
		
		if (currentPass != null && newPass != null && !currentPass.trim().isEmpty() && !newPass.trim().isEmpty()) {
			if(UserService.VerifyPassword(currentmyuser.getUserID(), currentPass)) {
				currentmyuser.setPasswords(newPass);
			}else {
				session.setAttribute("toastMessage", "Your Password is incorrect!");
				return "redirect:/User/profile-view";
			}
		}
		
		UserService.save(currentmyuser);
		session.setAttribute("currentmyuser", currentmyuser);
		session.setAttribute("toastMessage", "Profile updated successfully!");
		return "redirect:/User/profile-view";
	}
		
}
