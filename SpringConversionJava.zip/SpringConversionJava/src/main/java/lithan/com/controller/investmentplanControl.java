package lithan.com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import lithan.com.bean.investmentPlan;
import lithan.com.bean.myuser;
import lithan.com.service.ServiceInvestment;
import lithan.com.service.ServicePortfolio;

@Controller
public class investmentplanControl {
	@Autowired
	private ServicePortfolio portfolioService;
	
	@Autowired
	private ServiceInvestment investmentService;
	
	@RequestMapping("/User/Investment-Dashboard")
	public ModelAndView investmentDashboard(HttpSession session) {
		myuser sessionmyuser = (myuser) session.getAttribute("currentmyuser");
		if (sessionmyuser == null) {
			ModelAndView mav = new ModelAndView("form");
			return mav;
		}
		List<investmentPlan> investments = investmentService.listAll();
	    System.out.println(investments);

	    ModelAndView mav = new ModelAndView("User/Investment");
	    mav.addObject("investments", investments);
	    return mav;
	}	
		
	@GetMapping
	public ModelAndView saveInvestment(@RequestParam("initialAmount") Double initialAmount,
			@RequestParam("monthlyAmount") Double monthlyAmount, @RequestParam("investmentType") String investmentType,
			HttpSession session) {
		return new ModelAndView("client/investment-success");
	}
	
}
