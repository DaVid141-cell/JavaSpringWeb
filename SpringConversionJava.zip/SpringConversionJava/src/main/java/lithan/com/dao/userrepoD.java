package lithan.com.dao;

import org.springframework.data.repository.CrudRepository;

import lithan.com.bean.mybankuser;

public interface userrepoD extends CrudRepository<mybankuser, Long>{

}
