package lithan.com.dao;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import lithan.com.bean.myuser;

public interface UserRepo extends CrudRepository<myuser, Long> {
	
	Optional<myuser> findByusername(String username);
}


