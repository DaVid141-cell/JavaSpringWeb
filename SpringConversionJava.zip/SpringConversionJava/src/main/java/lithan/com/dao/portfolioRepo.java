package lithan.com.dao;

import org.springframework.data.repository.CrudRepository;

import lithan.com.bean.InvestmentPortfolio;
public interface portfolioRepo extends CrudRepository<InvestmentPortfolio, Long> {

}
