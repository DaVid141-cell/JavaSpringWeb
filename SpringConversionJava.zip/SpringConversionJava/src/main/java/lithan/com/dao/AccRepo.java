package lithan.com.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import lithan.com.bean.Account;

public interface AccRepo extends CrudRepository<Account, Long>{
	
	List<Account> findByUser_UserID(Long user_id);

}
