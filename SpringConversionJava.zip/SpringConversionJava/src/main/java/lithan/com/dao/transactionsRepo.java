package lithan.com.dao;

import org.springframework.data.repository.CrudRepository;

import lithan.com.bean.Transaction;

public interface transactionsRepo extends CrudRepository<Transaction, Long>{

}
