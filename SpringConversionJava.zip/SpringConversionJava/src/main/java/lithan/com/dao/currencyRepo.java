package lithan.com.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import lithan.com.bean.currency;

public interface currencyRepo extends CrudRepository<currency, Long>{
	
	Optional<currency> findBycode(String currencyCode);
}
