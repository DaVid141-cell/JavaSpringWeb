package lithan.com.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import lithan.com.bean.investmentPlan;

@Repository
public interface investmentPlanRepo extends CrudRepository<investmentPlan, Long> {
	
	investmentPlan findByPlanName(String planName);

}
