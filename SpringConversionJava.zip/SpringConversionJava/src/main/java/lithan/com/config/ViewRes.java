package lithan.com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@EnableWebMvc
@Configuration
@ComponentScan("lithan.com")
public class ViewRes implements WebMvcConfigurer{

	@Bean(name = "viewResolver")
	public InternalResourceViewResolver getViewResolver() {
	    InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
	    viewResolver.setPrefix("/WEB-INF/views/");
	    viewResolver.setSuffix(".jsp");
	    return viewResolver;
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		// TODO Auto-generated method stub
		registry.addResourceHandler("/css/**")
	       .addResourceLocations("/WEB-INF/resource/css/") ;
	registry.addResourceHandler("/js/**")
	      .addResourceLocations("/WEB-INF/resource/js/");
	registry.addResourceHandler("/images/**")
	 .addResourceLocations("/WEB-INF/resource/images/");
	registry.addResourceHandler("/fonts/**")
	 .addResourceLocations("/WEB-INF/resource/fonts/");
	}
	
}
