//form-slider

document.addEventListener("DOMContentLoaded", function () {
    const container = document.querySelector('.container');
    const registerBtn = document.querySelector('.register-btn'); // Toggle box register button
    const loginBtn = document.querySelector('.login-btn'); // Toggle box login button
    const navbarRegisterBtn = document.querySelector('#registerbtn'); // Navbar register button
    const navbarLoginBtn = document.querySelector('#loginbtn'); // Navbar login button

    // Show Register Form when clicking "Register" in the navbar
    if (navbarRegisterBtn) {
        navbarRegisterBtn.addEventListener('click', () => {
            container.classList.add('active'); // Switch to register form
        });
    }

    // Show Login Form when clicking "Login" in the navbar
    if (navbarLoginBtn) {
        navbarLoginBtn.addEventListener('click', () => {
            container.classList.remove('active'); // Switch back to login form
        });
    }

    // Toggle between login and register in the middle panel
    if (registerBtn) {
        registerBtn.addEventListener('click', () => {
            container.classList.add('active'); // Show register form
        });
    }

    if (loginBtn) {
        loginBtn.addEventListener('click', () => {
            container.classList.remove('active'); // Show login form
        });
    }
});
	
	// dropdown menu profile
	const dropbtn = document.querySelector("#dropbtn");
	        const dropcontent = document.querySelector(".dropdown-p");

	        dropbtn.addEventListener("click", () => {
	            event.stopPropagation();
	            dropcontent.classList.toggle('show');
	        });
	        
	        window.addEventListener('click', function(event){
	            if (!dropbtn.contains(event.target)) {
	                dropcontent.classList.remove('show');
	            }
	        });
	        
	 //animation icon    
	 document.getElementById("dropbtn").addEventListener("click", function() {
	        this.classList.toggle("active");

	        let isDown = this.getAttribute("name") === "caret-down-outline";
	        this.setAttribute("name", isDown ? "caret-up-outline" : "caret-down-outline");
	    	});
 
